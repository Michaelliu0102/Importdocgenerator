"""
Invoice 行 description / item_code 与申报品名、申报要素的映射。
出口优先读取 export_templates/出口申报要素对应表.xlsx 的 ITEM、品名、HS Code、申报要素四列。
"""

from __future__ import annotations

import copy
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from openpyxl import load_workbook

from config_loader import ConfigLoader

ROOT = Path(__file__).resolve().parent
DEFAULT_IMPORT_EXCEL = ROOT / "data" / "item和品名对应表.xlsx"
DEFAULT_EXPORT_EXCEL = ROOT / "export_templates" / "出口申报要素对应表.xlsx"
MappingRow = Dict[str, Any]

# 旧两列表 Excel 英文 ITEM 列与 YAML product_categories 键的对应
EXCEL_ITEM_TO_YAML_KEY: Dict[str, str] = {
    "Phone Case": "export_hs_392690_misc",
    "Airpods Case": "export_hs_392690_misc",
    "Watch Band": "export_hs_911390_watch",
    "Sunvisor Cover": "export_hs_392690_misc",
    "Pouch": "export_hs_392690_misc",
    "Lumbar Cushion": "export_hs_940199_auto",
    "Headrest Pillow": "export_hs_940199_auto",
    "Tray": "export_hs_392690_misc",
    "Bagpack": "export_hs_420212_luggage",
    "Luggage": "export_hs_420212_luggage",
    "Duffle Bag": "export_hs_420212_luggage",
    "Key Fob": "export_hs_392690_misc",
    "Card Holder": "export_hs_392690_misc",
    "Seat Cover": "alcantara_5015_5030_5010",
    "Notebook": "export_hs_482010_notebook",
    "Color Cards": "export_hs_491110_print",
    "Spectacle Case": "export_hs_392690_misc",
}


def _resolve_config_path(config_path: str) -> Path:
    p = Path(config_path)
    if not p.is_absolute():
        p = (Path.cwd() / p).resolve()
    else:
        p = p.resolve()
    return p


def _parse_declaration_elements(raw: Any, product_name: str) -> Dict[str, str]:
    """把 Excel D 列申报要素转成稳定的 dict；不强行理解无标签的管道格式。"""
    elements: Dict[str, str] = {}

    text = "" if raw is None else str(raw).strip()
    if product_name == "牛皮" and "|" in text:
        return _parse_cowhide_pipe_declaration(text, product_name)

    if product_name:
        elements["品名"] = product_name

    if not text:
        return elements

    normalized = (
        text.replace("\r\n", "\n")
        .replace("\r", "\n")
        .replace("；", "\n")
        .replace(";", "\n")
    )
    parts = [p.strip(" \t\n:：") for p in normalized.split("\n") if p.strip()]
    if len(parts) <= 1 and "|" in text:
        parts = [p.strip(" \t\n|") for p in text.split("|") if p.strip()]

    for idx, part in enumerate(parts, 1):
        key = ""
        value = ""
        if "：" in part:
            key, value = part.split("：", 1)
        elif ":" in part:
            key, value = part.split(":", 1)
        if key:
            key = key.strip()
            value = value.strip()
            elements[key or f"要素{idx}"] = value
        else:
            elements[f"要素{idx}"] = part.strip()
    return elements


def _parse_cowhide_pipe_declaration(raw: str, product_name: str) -> Dict[str, str]:
    """出口表牛皮行使用海关要素位序，转为可读字段名。"""
    parts = [p.strip(" \t\n\r；;") for p in raw.split("|")]

    def part(idx: int) -> str:
        return parts[idx].strip() if idx < len(parts) else ""

    color = ""
    color_usage = part(9)
    color_m = re.search(r"颜色[:：]?\s*([^。.\s]+)", color_usage)
    if color_m:
        color = color_m.group(1).strip()

    spec_bits = [part(5), part(7)]
    spec = "，".join(bit for bit in spec_bits if bit)

    return {
        "涂覆": part(2),
        "粒面层": part(3),
        "动物种类": part(4),
        "规格": spec,
        "颜色": color or "等",
        "用途": "用于家具包覆",
        "鞣制": part(12),
        "计量单位": part(13).strip(" ；;") or "张",
        "品名": product_name,
    }


def load_excel_mapping_rows(xlsx_path: Path) -> List[MappingRow]:
    """返回 Excel 映射行，兼容旧两列表和出口四列表。"""
    if not xlsx_path.exists():
        return []
    wb = load_workbook(xlsx_path, read_only=True, data_only=True)
    try:
        ws = wb.active
        rows: List[MappingRow] = []
        for row_no, row in enumerate(ws.iter_rows(values_only=True), start=1):
            if row_no == 1:
                continue
            if not row or len(row) < 2:
                continue
            a, b = row[0], row[1]
            if a is None or b is None:
                continue
            item_en = str(a).strip()
            name_cn = str(b).strip()
            if not item_en or not name_cn:
                continue
            hs_code = str(row[2]).strip() if len(row) > 2 and row[2] else ""
            raw_elements = row[3] if len(row) > 3 else None
            rows.append(
                {
                    "row_no": row_no,
                    "item": item_en,
                    "product_name": name_cn,
                    "hs_code": hs_code,
                    "declaration_elements": _parse_declaration_elements(
                        raw_elements, name_cn
                    ),
                }
            )
        return rows
    finally:
        wb.close()


def _match_excel_row(
    item: Dict[str, Any], excel_rows: List[MappingRow]
) -> Optional[MappingRow]:
    """按出口对应表行号语义匹配；旧表则按 ITEM 子串匹配。"""
    description = _item_desc_for_declaration(item)
    d = (description or "").strip().lower()
    if not excel_rows:
        return None

    # A2-A20: ITEM on Invoice，按英文 ITEM 名称匹配，取最长命中。
    best: Optional[MappingRow] = None
    best_len = -1
    if d:
        for row in excel_rows:
            row_no = int(row.get("row_no") or 0)
            if row_no and not (2 <= row_no <= 20):
                continue
            item_en = str(row.get("item") or "").strip()
            ie = item_en.lower()
            if not ie:
                continue
            if ie in d and len(ie) > best_len:
                best = row
                best_len = len(ie)
    if best:
        return best

    candidates = _item_prefix_candidates(item)
    for row in excel_rows:
        row_no = int(row.get("row_no") or 0)
        raw_item = str(row.get("item") or "").strip()
        prefixes = [_normalize_prefix_token(p) for p in raw_item.split("/") if p]

        if row_no == 21:
            if any(_candidate_starts_with(candidates, p, 4) for p in prefixes):
                return row
        elif row_no == 22:
            if any(_candidate_starts_with(candidates, p, len(p)) for p in prefixes):
                return row
        elif 23 <= row_no <= 25:
            if any(_candidate_starts_with(candidates, p, 6) for p in prefixes):
                return row
        elif row_no == 26:
            if any(_candidate_starts_with(candidates, p, 2) for p in prefixes):
                return row
    return None


def _normalize_prefix_token(value: Any) -> str:
    return re.sub(r"[^A-Z0-9]", "", str(value or "").upper())


def _strip_line_number(value: Any) -> str:
    # CustInvc 行项目常见 "1MF ..." / "4VERONA ..."，但 50153335BP 这种数字料号不能被剥掉。
    return re.sub(r"^\s*\d{1,3}(?=[A-Za-z])\s*", "", str(value or "").strip())


def _item_prefix_candidates(item: Dict[str, Any]) -> List[str]:
    values = [
        item.get("item_code"),
        item.get("article_name"),
        item.get("description"),
        item.get("description_supplement"),
        _item_desc_for_declaration(item),
    ]
    candidates: List[str] = []
    for value in values:
        raw = _strip_line_number(value)
        norm = _normalize_prefix_token(raw)
        if norm and norm not in candidates:
            candidates.append(norm)
        # 聚合后的皮料行可能是 "LEATHER ART. NAPPA ..."，也要让 ART 后的货号参与判断。
        art = re.search(r"\bART\.?\s+([A-Z0-9]+)", raw, re.IGNORECASE)
        if art:
            norm_art = _normalize_prefix_token(art.group(1))
            if norm_art and norm_art not in candidates:
                candidates.append(norm_art)
    return candidates


def _candidate_starts_with(
    candidates: List[str], prefix: str, significant_len: int
) -> bool:
    p = _normalize_prefix_token(prefix)[:significant_len]
    return bool(p) and any(c.startswith(p) for c in candidates)


def _first_four_digits(item_code: Any) -> Optional[str]:
    if item_code is None:
        return None
    digits = re.sub(r"\D", "", str(item_code).strip())
    if len(digits) >= 4:
        return digits[:4]
    return None


def _leading_after_line_digits(s: str) -> str:
    """去掉行首数字编号后用于 MF / 皮革前缀判断。"""
    t = (s or "").strip()
    t = re.sub(r"^\d+[\s\-]*", "", t)
    return t.strip()


def _mf_prefix(description: str) -> bool:
    lead = _leading_after_line_digits(description)
    return len(lead) >= 2 and lead[:2].upper() == "MF"


def _leather_keyword_prefix(description: str) -> bool:
    """NAPPA / VERONA / ROMA 为去掉行首数字后的字母前缀（大小写不敏感）。"""
    s = _leading_after_line_digits(description)
    if not s:
        return False
    u = s.upper()
    if len(u) >= 5 and u.startswith("NAPPA"):
        return True
    if len(u) >= 6 and u.startswith("VERONA"):
        return True
    if len(u) >= 4 and u.startswith("ROMA"):
        return True
    return False


def _product_block_from_yaml(
    loader: ConfigLoader, key: str
) -> Dict[str, Any]:
    pi = loader.get_product_info(key) or {}
    return {
        "hs_code": (pi.get("hs_code") or "").strip(),
        "product_name": (pi.get("name") or "").strip(),
        "declaration_elements": copy.deepcopy(pi.get("declaration_elements") or {}),
    }


def _product_block_from_excel(row: MappingRow) -> Dict[str, Any]:
    product_name = str(row.get("product_name") or "").strip()
    return {
        "hs_code": str(row.get("hs_code") or "").strip(),
        "product_name": product_name,
        "declaration_elements": copy.deepcopy(
            row.get("declaration_elements") or {"品名": product_name}
        ),
    }


def _with_cn_name(
    block: Dict[str, Any], name_cn: str
) -> Dict[str, Any]:
    out = {
        "hs_code": block["hs_code"],
        "product_name": name_cn,
        "declaration_elements": copy.deepcopy(block["declaration_elements"]),
    }
    decl = out["declaration_elements"]
    if name_cn:
        decl["品名"] = name_cn
    return out


def _item_desc_for_declaration(item: Dict[str, Any]) -> str:
    """Alcantara：品名列用 Material；申报/ITEM 匹配时拼接可选的 Description 栏。"""
    sup = (item.get("description_supplement") or "").strip()
    mat = (item.get("description") or "").strip()
    return f"{sup} {mat}".strip() if sup else mat


def resolve_item_declaration(
    item: Dict[str, Any],
    excel_rows: List[MappingRow],
    loader: ConfigLoader,
    product_info: Optional[Dict[str, Any]],
    product_info_map: Dict[str, Dict[str, Any]],
) -> Dict[str, Any]:
    """
    返回单行的 hs_code, product_name, declaration_elements（已深拷贝）。
    """
    desc = _item_desc_for_declaration(item)
    pi_default = product_info or {}

    # 1) Excel ITEM 表
    ex = _match_excel_row(item, excel_rows)
    if ex:
        if ex.get("hs_code"):
            return _product_block_from_excel(ex)
        item_en = str(ex.get("item") or "").strip()
        name_cn = str(ex.get("product_name") or "").strip()
        yk = EXCEL_ITEM_TO_YAML_KEY.get(item_en)
        if yk:
            blk = _product_block_from_yaml(loader, yk)
            if blk.get("hs_code") or blk.get("declaration_elements"):
                return _with_cn_name(blk, name_cn)

    # 2) hide_type（与旧逻辑一致，在数字/MF/皮革规则之前便于专用皮料）
    hide_type = (item.get("hide_type") or "").strip()
    if hide_type and hide_type in product_info_map:
        cur = product_info_map[hide_type]
        return {
            "hs_code": (cur.get("hs_code") or "").strip(),
            "product_name": (cur.get("name") or "").strip(),
            "declaration_elements": copy.deepcopy(
                cur.get("declaration_elements") or {}
            ),
        }

    # 3) item 前四位 5012 / 5015 → 面料 5603149000
    d4 = _first_four_digits(item.get("item_code"))
    if d4 == "5012":
        blk = _product_block_from_yaml(loader, "alcantara_5012")
        return _with_cn_name(blk, "面料")
    if d4 == "5015":
        blk = _product_block_from_yaml(loader, "alcantara_5015_5030_5010")
        return _with_cn_name(blk, "面料")

    # 4) MF 开头 → 超细纤维革 5903209000
    if _mf_prefix(desc):
        blk = _product_block_from_yaml(loader, "export_microfibre_hs5903209000")
        return _with_cn_name(blk, blk["product_name"] or "超细纤维革")

    # 5) NAPPA / VERONA / ROMA → 牛皮 4107121090
    if _leather_keyword_prefix(desc):
        blk = _product_block_from_yaml(loader, "mabo_cowhide")
        return _with_cn_name(blk, "牛皮")

    # 6) 默认 invoice 级 product_info
    return {
        "hs_code": (pi_default.get("hs_code") or "").strip(),
        "product_name": (pi_default.get("name") or "").strip(),
        "declaration_elements": copy.deepcopy(
            pi_default.get("declaration_elements") or {}
        ),
    }


def build_declaration_groups(
    items: List[Dict[str, Any]],
    invoice_data: Dict[str, Any],
    product_info: Optional[Dict[str, Any]],
    product_info_map: Optional[Dict[str, Dict[str, Any]]],
    config_path: str,
    mapping_xlsx: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """
    使用 item/品名 对应表与回落规则分组，结构同 DeclarationElementsGenerator._group_items_by_product。
    若未启用或缺少映射表，调用方应改用旧 _group_items_by_product。
    """
    cfg_path = _resolve_config_path(config_path)
    if not cfg_path.exists():
        cfg_path = ROOT / "data" / "supplier_product_mapping_import.yaml"
        if not cfg_path.exists():
            cfg_path = ROOT / "data" / "supplier_product_mapping.yaml"
    loader = ConfigLoader(str(cfg_path))

    xlsx = _resolve_mapping_xlsx_path(str(cfg_path), mapping_xlsx, invoice_data)
    excel_rows = load_excel_mapping_rows(xlsx)

    pim = product_info_map or {}
    if not items:
        pi = product_info or {}
        return [
            {
                "hs_code": pi.get("hs_code", ""),
                "product_name": pi.get("name", ""),
                "declaration_elements": copy.deepcopy(
                    pi.get("declaration_elements") or {}
                ),
                "items": [],
            }
        ]

    groups: Dict[Tuple[str, str], Dict[str, Any]] = {}

    for item in items:
        resolved = resolve_item_declaration(
            item, excel_rows, loader, product_info, pim
        )
        key = (resolved["hs_code"], resolved["product_name"])
        if key not in groups:
            groups[key] = {
                "hs_code": resolved["hs_code"],
                "product_name": resolved["product_name"],
                "declaration_elements": resolved["declaration_elements"],
                "items": [],
            }
        groups[key]["items"].append(item)

    return list(groups.values())


def _resolve_mapping_xlsx_path(
    config_path: str,
    mapping_xlsx: Optional[str],
    invoice_data: Optional[Dict[str, Any]],
) -> Path:
    ovr = (invoice_data or {}).get("item_mapping_xlsx") or mapping_xlsx
    if ovr:
        p = Path(ovr)
        return p.resolve() if p.is_absolute() else (Path.cwd() / p).resolve()
    cfg = _resolve_config_path(config_path)
    if "export" in cfg.stem.lower() and DEFAULT_EXPORT_EXCEL.exists():
        return DEFAULT_EXPORT_EXCEL
    default_import = cfg.parent / "item和品名对应表.xlsx"
    return default_import if default_import.exists() else DEFAULT_IMPORT_EXCEL


def use_item_mapping_enabled(invoice_data: Dict[str, Any]) -> bool:
    """默认启用 ITEM/品名映射与回落规则；invoice_data['use_item_mapping']==False 时退回旧分组。"""
    return invoice_data.get("use_item_mapping", True) is not False
